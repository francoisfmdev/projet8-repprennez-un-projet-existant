storage.findAll.and.callFake(function () {
	return { title: "findAll" };
});
storage.find.and.callFake(function () {
	return { title: "find" };
});




model.read(function () { }, null);



//	let returnValue = newModel.read("", null);
let expectedValue = { title: "findAll" };

//expect(returnValue).toEqual(expectedValue);




var newModel;
newModel = jasmine.createSpyObj('model', ['read']).read.and.callFake(function (query, callback) {
	callback = callback || query;
	callback(todos);
});