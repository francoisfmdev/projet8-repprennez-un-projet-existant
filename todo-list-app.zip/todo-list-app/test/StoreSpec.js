/*global app, jasmine, describe, it, beforeEach, expect */

describe('model', function () {
    'use strict';

    var store, model;





    beforeEach(function () {

        store = jasmine.createSpyObj('store', ['find', 'findAll']);

        store.findAll.and.callFake(function () {
            return { title: "findAll" };
        });
        store.find.and.callFake(function () {
            return { title: "find" };
        });

        model = new app.Model(store);




    });



    describe('findAll', function () {




        it('execute findAll', function () {

            let returnValue = model.read(function () { }, null);

            let expectedValue = { title: "findAll" };

            expect(returnValue).toEqual(expectedValue);

        });

    });

    describe('find', function () {




        it('execute find', function () {

            let returnValue = model.read("", null);

            let expectedValue = { title: "find" };

            expect(returnValue).toEqual(expectedValue);

        });

    });

});
